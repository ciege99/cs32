#include "Actor.h"
#include "StudentWorld.h"
#include "GameConstants.h"
#include "GraphObject.h"

// Students:  Add code to this file, Actor.h, StudentWorld.h, and StudentWorld.cpp

//constructors

BaseActor::BaseActor(int imageID, double startX,
                    double startY, Direction dir, int depth, StudentWorld *world) :
                    GraphObject(imageID, startX, startY, dir, depth),
                    m_alive(true), m_world(world), m_isInfected(false)
                    {}

MoveableActors::MoveableActors(int imageID, double startX,
                    double startY, Direction dir, int depth, StudentWorld* world) :
                    BaseActor (imageID, startX, startY, dir, depth, world), m_ticks(0)
                    {}

Humans::Humans(int imageID, double startX, double startY,
                    Direction dir, int depth, StudentWorld* world) :
                    MoveableActors(imageID, startX, startY, dir, depth, world),
                    m_infectedTotal(0)
                    {}

Zombies::Zombies(double startX, double startY, Direction dir,
                 int depth, StudentWorld* world) : MoveableActors(IID_ZOMBIE, startX, startY, dir, depth, world), m_planDist(0)
                    {}

Penelope::Penelope(double startX, double startY, StudentWorld* world) :
                    Humans(IID_PLAYER, startX, startY, right, 0, world), m_landmines(0), m_vaccines(0), m_flames(0)
                    {}


Environment::Environment(int imageID, double startX, double startY,
                    Direction dir, int depth, StudentWorld* world) :
                    BaseActor(imageID, startX, startY, dir, depth, world)
                    {}

Goodies::Goodies(int imageID, double startX, double startY, Direction dir, int
                    depth, StudentWorld* world) : Environment(imageID, startX,
                    startY, dir, depth, world)
                    {}



Permanents::Permanents(int imageID, double startX, double startY, Direction dir,
                    int depth, StudentWorld* world) :
                    Environment(imageID, startX, startY, dir, depth, world)
                    {}

Citizens::Citizens(double startX, double startY, StudentWorld* world) :
                    Humans(IID_CITIZEN, startX, startY, right, 0, world)
                    {}

DumbZombies::DumbZombies(double startX, double startY, StudentWorld* world) :
                    Zombies(startX, startY, right, 0, world)
                    {}

SmartZombies::SmartZombies(double startX, double startY, StudentWorld* world) :
                    Zombies(startX, startY, right, 0, world)
                    {}

Vaccine::Vaccine(double startX, double startY, StudentWorld* world) :
                    Goodies(IID_VACCINE_GOODIE, startX, startY, right, 1, world)
                    {}

GasCan::GasCan(double startX, double startY, StudentWorld* world) :
                    Goodies(IID_GAS_CAN_GOODIE, startX, startY, right, 1, world)
                    {}
LandmineGoodie::LandmineGoodie(double startX, double startY, StudentWorld*
                    world) :
                    Goodies(IID_LANDMINE_GOODIE, startX, startY, right, 1, world)
                    {}

Landmine::Landmine(double startX, double startY, StudentWorld* world) :
                    Goodies(IID_LANDMINE, startX, startY, right, 1, world),
                    m_safetyTicks(30)
                    {}

Projectiles::Projectiles(int imageID, double startX, double startY,
                    Direction dir, int depth, StudentWorld* world) :
                    Permanents(imageID, startX, startY, dir, depth, world),
                    lifespan(2)
                    {}

Pits::Pits(double startX, double startY, StudentWorld* world) :
                    Permanents(IID_PIT, startX, startY, right, 0, world)
                    {}

Walls::Walls(double startX, double startY, StudentWorld* world) :
                    Permanents(IID_WALL, startX, startY, right, 0, world)
                    {}

Exits::Exits(double startX, double startY, StudentWorld* world) :
                    Permanents(IID_EXIT, startX, startY, right, 1, world)
                    {}


Flames::Flames(double startX, double startY, StudentWorld* world) :
                    Projectiles(IID_FLAME, startX, startY, right, 0, world)
                    {}

Vomit::Vomit(double startX, double startY, StudentWorld* world) :
                    Projectiles(IID_VOMIT, startX, startY, right, 0, world)
{
    this->getWorld()->playSound(SOUND_ZOMBIE_VOMIT);
}
                                                                  


// doSomething



void Environment::doSomething() {
    return;     //most environment actors do nothing, so this is good default
}


// BaseActor functions
bool BaseActor::isAlive() {
    return m_alive;
}

void BaseActor::beKilled() {
    this->setDead();
}

bool BaseActor::notBlock() {
    return true;
}

bool BaseActor::flameCannotOverlap() {
    return false;
}

StudentWorld* BaseActor::getWorld() {
    return m_world;
}

bool BaseActor::isMoveable() {
    return false;
}


bool BaseActor::canBeInfected() {
    return false;   //default to false
}



bool BaseActor::canBeKilled() {
    return true;
}

bool BaseActor::isInfected() {
    return m_isInfected;
}

int Humans::getInfectedTotal() {
    return m_infectedTotal;
}

void Humans::setHealthy() {
    setInfected();
    m_infectedTotal = 0;
}

void Humans::increaseInfectedTotal() {
    m_infectedTotal++;
}

void BaseActor::setInfected() {
    m_isInfected = true;
}


void BaseActor::setDead() {
    m_alive = false;
}


// MoveableActors functions

bool MoveableActors::isMoveable() {
    return true;
}

int MoveableActors::getTicks() {
    return m_ticks;
}

void MoveableActors::increaseTicks() {
    m_ticks++;
}

void MoveableActors::setTicksZero() {
    m_ticks = 0;
}

void MoveableActors::setTicks(int n) {
    m_ticks = n;
}

void MoveableActors::decreaseTicks() {
    m_ticks--;
}

void MoveableActors::onCollision(BaseActor *a) {
    return;
}

bool MoveableActors::notBlock() {
    return false;   // moveable actors can't overlap
}

// Humans functions

bool Humans::commonHumanActions() {
    if (! this->isAlive() ) //check that human is alive
        return false;
    
    if (this->isInfected())         //return false if it should stop
    {
        this->increaseInfectedTotal();
        if (this->getInfectedTotal() >= 500)
        {
            this->beKilled();   //from BaseActor class
            this->getWorld()->playSound(SOUND_PLAYER_DIE);
            return false;
        }
    }
    
    return true;
}

void Humans::doSomething() {
    
    if (! commonHumanActions())
        return;
    
    
}


bool Humans::canBeInfected() {
    return true;
}


// Penelope functions

void Penelope::doSomething() {
    if (! commonHumanActions())
        return;
    
    
    int ch;
    if (this->getWorld()->getKey(ch))
    {
        double oldX = this->getX();
        double oldY = this->getY();
        switch (ch) {
            case KEY_PRESS_LEFT:
                setDirection(left);
                if (! this->getWorld()->overlap(oldX-P_MOVE, oldY, this))
                    break;
                this->moveTo(oldX-P_MOVE, oldY);
                break;
            case KEY_PRESS_RIGHT:
                setDirection(right);
                if (! this->getWorld()->overlap(oldX+P_MOVE, oldY, this))
                    break;
                this->moveTo(oldX+P_MOVE, oldY);
                break;
            case KEY_PRESS_UP:
                setDirection(up);
                if (! this->getWorld()->overlap(oldX, oldY+P_MOVE, this))
                    break;
                this->moveTo(oldX, oldY+P_MOVE);
                break;
            case KEY_PRESS_DOWN:
                setDirection(down);
                if (! this->getWorld()->overlap(oldX, oldY-P_MOVE, this))
                    break;
                this->moveTo(oldX, oldY-P_MOVE);
                break;
            case KEY_PRESS_SPACE:
                this->flamethrower();
                break;
            case KEY_PRESS_TAB:
                this->placeLandmine();
                break;
            case KEY_PRESS_ENTER:
                this->useVaccine();
                break;
        }
    
    }
}

void Penelope::flamethrower() {
    if (m_flames <= 0)
    {
        return; //return if no gas
    }
    
    m_flames--;
    this->getWorld()->playSound(SOUND_PLAYER_FIRE);
    this->getWorld()->createFlamethrower(getX(), getY(), getDirection());
    
}


void Penelope::placeLandmine() {
    if (m_landmines > 0) {
        m_landmines--;
        this->getWorld()->createLandmine(this->getX(), this->getY());
    }
}

void Penelope::useVaccine() {
    if (m_vaccines > 0) {
        this->setHealthy();
        m_vaccines--;
    }
}

void Penelope::addVaccine() {
    m_vaccines++;
}

void Penelope::addLandmines() {
    m_landmines += 2;
}

void Penelope::addFlames() {
    m_flames += 5;
}

int Penelope::getVaccines() {
    return m_vaccines;
}

int Penelope::getLandmines() {
    return m_landmines;
}

int Penelope::getFlames() {
    return m_flames;
}

void Penelope::beKilled() {
    getWorld()->playSound(SOUND_PLAYER_DIE);
    this->setDead();
}


// Citizens functions

void Citizens::beKilled() {
    getWorld()->playSound(SOUND_PLAYER_DIE);
    this->setDead();
}

void Citizens::doSomething() {
    
}


// Zombies functions

bool Zombies::commonZombieActions() {
    if (! this->isAlive())  //part 1        //return false if zombie should stop
        return false;
    
    
    this->increaseTicks();  //part 2
    if (this->getTicks() >= 2)
    {
        this->setTicksZero();    // paralysis tick
        return false;
    }
    
    if (this->getWorld()->vomitDistance(this))  // part 3 vomit
        this->getWorld()->playSound(SOUND_ZOMBIE_VOMIT);
    
    return true;
}


void Zombies::modifyPlanDist(int n) {
    m_planDist += n;
}

int Zombies::getPlanDist() {
    return m_planDist;
}

void Zombies::setPlanDistZero() {
    m_planDist = 0;
}

void Zombies::beKilled() {
    this->getWorld()->playSound(SOUND_ZOMBIE_DIE);
    this->setDead();
}

void Zombies::randomPlanDist() {
    int n = randInt(3, 10);
    this->modifyPlanDist(n);
}

void Zombies::randomDirectionSelector() {
    
    switch (randInt(1, 4)) {
        case 1:
            this->setDirection(right);
            break;
        case 2:
            this->setDirection(left);
            break;
        case 3:
            this->setDirection(up);
            break;
        case 4:
            this->setDirection(down);
            break;
    }
}

void Zombies::mover() {
    switch (this->getDirection()) {
        case right:
            if (this->getWorld()->overlap(getX()+Z_MOVE, getY(), this))
            {
                this->moveTo(getX()+Z_MOVE, getY());
                this->modifyPlanDist(-1);
            }
            else
                this->setPlanDistZero();
            break;
        case left:
            if (this->getWorld()->overlap(getX()-Z_MOVE, getY(), this))
            {
                this->moveTo(getX()-Z_MOVE, getY());
                this->modifyPlanDist(-1);
            }
            else
                this->setPlanDistZero();
            break;
        case up:
            if (this->getWorld()->overlap(getX(), getY()+Z_MOVE, this))
            {
                this->moveTo(getX(), getY()+Z_MOVE);
                this->modifyPlanDist(-1);
            }
            else
                this->setPlanDistZero();
            break;
        case down:
            if (this->getWorld()->overlap(getX(), getY()-Z_MOVE, this))
            {
                this->moveTo(getX(), getY()-Z_MOVE);
                this->modifyPlanDist(-1);
            }
            else
                this->setPlanDistZero();
            break;
    }
}

// Goodies functions





// Permanents functions
bool Permanents::canBeKilled() {
    return false;
}


// DumbZombie functions



void DumbZombies::doSomething() {
    
    if (! commonZombieActions())
        return;
    
    if (this->getPlanDist() == 0) // part 4 set direction
    {
        randomPlanDist();
        randomDirectionSelector();
    }
    
    this->mover();
    
}


// SmartZombie functions



void SmartZombies::doSomething() {
    if (! commonZombieActions())
        return;
    
    if (this->getPlanDist() == 0)
    {
        randomPlanDist();
        if (! getWorld()->findClosestHuman(this))   //if no human to move to
            randomDirectionSelector();              //set random dir
    }
    
    this->mover();
}



// Vaccine Goodie functions
void Vaccine::onCollision(BaseActor *a) {
    if (getWorld()->addVaccine(a))
        this->beKilled();
}

// Landmine Goodie functions

void LandmineGoodie::onCollision(BaseActor *a) {
    if (getWorld()->addLandmines(a))
        this->beKilled();
}


// Landmine functions
void Landmine::onCollision(BaseActor *a) {
    if (m_safetyTicks <= 0)
    {
        this->getWorld()->createLandmineExplosion(getX(), getY());
        this->beKilled();
    }
}

void Landmine::doSomething() {
    if (m_safetyTicks > 0)
        m_safetyTicks--;
}


// GasCan Goodie functions
void GasCan::onCollision(BaseActor *a) {
    if (getWorld()->addFlames(a))
        this->beKilled();
}


// Projectiles functions
void Projectiles::doSomething() {
    this->getWorld()->overlap(getX(), getY(), this);
    if ( this->isAlive())
    {
        lifespan--;
        if (lifespan <= 0)  //projectiles only last two ticks
            this->beKilled();
    }
}


// Pits functions
void Pits::onCollision(BaseActor *a) {
    a->beKilled();
}


// Walls functions

void Walls::onCollision(BaseActor *a) {
    return;
}

bool Walls::notBlock() {
    return false;
}

bool Walls::flameCannotOverlap() {
    return true;
}



// Exits functions

void Exits::onCollision(BaseActor *a) {
    this->getWorld()->playerExit(a); //try to let player exit
}


bool Exits::flameCannotOverlap() {
    return true;
}


// Flames functions

void Flames::onCollision(BaseActor *a) {
    if (this->isAlive())
    {
        if ( a->canBeKilled() )
        {
            a->onCollision(nullptr);
            a->beKilled();
        }
    }
}





//Vomit functions

void Vomit::onCollision(BaseActor *a) {
    if (this->isAlive() && a->canBeInfected())
        a->setInfected();

}
