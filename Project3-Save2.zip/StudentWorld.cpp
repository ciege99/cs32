#include "StudentWorld.h"
#include "Actor.h"
#include "GraphObject.h"
#include "GameConstants.h"
#include "Level.h"
#include <string>
#include <list>
#include <iostream>
#include <sstream>
#include <iomanip>
#include <cmath>
using namespace std;

GameWorld* createStudentWorld(string assetPath)
{
	return new StudentWorld(assetPath);
}

// Students:  Add code to this file, StudentWorld.h, Actor.h and Actor.cpp

StudentWorld::StudentWorld(string assetPath)
: GameWorld(assetPath), character(nullptr), numHumans(0), levelWon(false), numPoints(0)
{}

StudentWorld::~StudentWorld() {
    this->cleanUp();
}


int StudentWorld::init()
{
    levelWon = false; // start out a level not won
    
    
    ostringstream oss;  //set levelFile
    oss << "level";
    oss << setw(2) << setfill('0') << getLevel();
    oss << ".txt";
    
    //string levelFile = oss.str();
    string levelFile = "level04.txt";
    Level lev(assetPath());
    lev.loadLevel(levelFile);
    for (double i = 0; i < 16; i++)
        for (double j = 0; j < 16; j++)
        {
            Level::MazeEntry ge;
            ge = lev.getContentsOf(i, j);
            switch (ge)
            {
                case Level::empty:
                    break;
                case Level::player:
                    character = new Penelope(i*SPRITE_WIDTH, j*SPRITE_HEIGHT, this);
                    actors.push_back(character);
                    break;
                case Level::citizen:
                    numHumans++;
                    break;
                case Level::vaccine_goodie:
                    actors.push_back(new Vaccine(i*SPRITE_WIDTH, j*SPRITE_HEIGHT, this));
                    break;
                case Level::landmine_goodie:
                    actors.push_back(new LandmineGoodie(i*SPRITE_WIDTH, j*SPRITE_HEIGHT, this));
                    break;
                case Level::gas_can_goodie:
                    actors.push_back(new GasCan(i*SPRITE_WIDTH, j*SPRITE_HEIGHT, this));
                    break;
                case Level::pit:
                    actors.push_back(new Pits(i*SPRITE_WIDTH, j*SPRITE_HEIGHT, this));
                    break;
                case Level::wall:
                    actors.push_back(new Walls(i*SPRITE_WIDTH, j*SPRITE_HEIGHT, this));
                    break;
                case Level::exit:
                    actors.push_back(new Exits(i*SPRITE_WIDTH, j*SPRITE_HEIGHT, this));
                    break;
                case Level::dumb_zombie:
                    actors.push_back(new DumbZombies(i*SPRITE_WIDTH, j*SPRITE_HEIGHT, this));
                    break;
                case Level::smart_zombie:
                    actors.push_back(new SmartZombies(i*SPRITE_WIDTH, j*SPRITE_HEIGHT, this));
                    break;
                default:
                    break;
            }
        }

    this->setStats();
    
    //character = new Penelope(200, 200, this);
    //actors.push_back(new Walls(0, 0, this));
    return GWSTATUS_CONTINUE_GAME;
}

int StudentWorld::move()
{
    // This code is here merely to allow the game to build, run, and terminate after you hit enter.
    // Notice that the return value GWSTATUS_PLAYER_DIED will cause our framework to end the current level.
    character->doSomething();
    if (! character->isAlive())
    {
        decLives();
        return GWSTATUS_PLAYER_DIED;
    }
    
    if (levelWon == true)
        return GWSTATUS_FINISHED_LEVEL;
    
    list<BaseActor*>::iterator it;
    for (it = actors.begin(); it != actors.end(); it++)
    {
        
        if ( (*it)->isAlive() )
            (*it)->doSomething();
        if (! character-> isAlive())
        {
            decLives();
            return GWSTATUS_PLAYER_DIED;
        }
        
        if (levelWon == true)
            return GWSTATUS_FINISHED_LEVEL;
    }
    
    //this loop will erase the dead actors from the frame
    it = actors.begin();
    while (it != actors.end())
    {
        if ( !(*it)->isAlive())
        {
            BaseActor* temp = (*it);
            delete temp;
            it = actors.erase(it);
            
        }
        else
            it++;
    }
    
    this->setStats();
    return GWSTATUS_CONTINUE_GAME;
}

void StudentWorld::cleanUp()
{

    std::list<BaseActor*>::iterator it;
    it = actors.begin();
    
    while (it != actors.end())
    {
        BaseActor* temp = (*it);
        delete temp;
        it = actors.erase(it);
    }
}


bool StudentWorld::overlap(double newX, double newY, BaseActor *a) {

    std::list<BaseActor*>::iterator it;
    it = actors.begin();
    while (it != actors.end())
    {
        if ((*it) == a) // if the iterator is pointing to same actor as passed in
        {
            it++;
            continue;
        }
        double bX, bY, dX, dY;
        
        if ((! (*it)->isAlive()) || (! a->isAlive()) ) //make sure they're alive
            return false;
        
        bX = (*it)->getX();
        bY = (*it)->getY();
        dX = newX - bX; //differences between the positions
        dY = newY - bY;
        
        if (! blockMovement(newX, newY, a))
            return false;
        else if (((dX*dX) + (dY*dY)) <= 100)
        {
            if ((*it)->isAlive() && a->isAlive())
            {
                a->onCollision((*it));
                (*it)->onCollision(a);
                return true;
                
            }
        }
        it++;
    }
    return true;
}

bool StudentWorld::validFlamePosition(BaseActor *a) {
    list<BaseActor*>::iterator it;
    it = actors.begin();
//    for (it = actors.begin(); it != actors.end(); it++)
//    {
//        if ( (*it)->flameCannotOverlap() )
//            return false;
//    }
//    return true;
    double newX, newY;
    newX = a->getX();
    newY = a->getY();
    
    while (it != actors.end())
    {
        if ((*it) == a) // if the iterator is pointing to same actor as passed in
        {
            it++;
            continue;
        }
        double bX, bY, dX, dY;
        
        if ((! (*it)->isAlive()) || (! a->isAlive()) ) //make sure they're alive
            return false;
        
        bX = (*it)->getX();
        bY = (*it)->getY();
        dX = newX - bX; //differences between the positions
        dY = newY - bY;
        
        if ((*it)->flameCannotOverlap()) //Both block movement
        {
            if (((dX*dX) + (dY*dY)) <= 100)
                return false;     //don't let flames overlap walls or exits
        }
        it++;
    }
    return true;
}


bool StudentWorld::blockMovement(double newX, double newY, BaseActor *a)
{
    std::list<BaseActor*>::iterator it;
    it = actors.begin();
    while (it != actors.end())
    {
        if ((*it) == a) // if the iterator is pointing to same actor as passed in
        {
            it++;
            continue;
        }
        double bX, bY;
        
        if ((! (*it)->isAlive()) || (! a->isAlive()) ) //make sure they're alive
            return false;
        
        bX = (*it)->getX();
        bY = (*it)->getY();
        
        if (! (*it)->notBlock() && ! a->notBlock()) //Both block movement
        {
            if ((newX >= bX && newX <= bX+SPRITE_WIDTH-1 &&
                 newY >= bY && newY <= bY+SPRITE_HEIGHT-1) ||
                (newX+SPRITE_WIDTH-1 >= bX && newX+SPRITE_WIDTH-1 <= bX+SPRITE_WIDTH-1 &&
                 newY >= bY && newY <= bY+SPRITE_HEIGHT-1) ||
                (newX >= bX && newX <= bX+SPRITE_WIDTH-1 &&
                 newY+SPRITE_HEIGHT-1 >= bY && newY+SPRITE_HEIGHT-1 <= bY+SPRITE_HEIGHT-1) ||
                (newX+SPRITE_WIDTH-1 >= bX && newX+SPRITE_WIDTH-1 <= bX+SPRITE_WIDTH-1 &&
                 newY+SPRITE_HEIGHT-1 >= bY && newY+SPRITE_HEIGHT-1 <= bY+SPRITE_HEIGHT-1))
                return false;   //don't let actors touch walls or each other
        }
        it++;
    }
        return true;
}


int StudentWorld::getHumans() {
    return numHumans;
}

void StudentWorld::setLevelWin() {
    levelWon = true;
}

void StudentWorld::modifyPoints(int num) {
    numPoints += num;
}


void StudentWorld::setStats() {
    ostringstream oss;
    oss << "Score: ";
    oss << setfill('0') << setw(6) << numPoints;
    oss << "  Level: ";
    oss  << getLevel();
    oss << "  Lives: " << setw(1) << getLives();
    oss << "  Vacc: " << character->getVaccines();
    oss << "  Flames: " << character->getFlames();
    oss << "  Mines: " << character->getLandmines();
    oss << "  Infected: " << character->getInfectedTotal();
    oss << endl;
    string output = oss.str();
    this->setGameStatText(output);
}


bool StudentWorld::vomitDistance(BaseActor* z) {
    list<BaseActor*>::iterator it;
    for (it = actors.begin(); it != actors.end(); it++)
    {
        if ((*it)->canBeInfected())
        {
            double humanXCoord = (*it)->getX();
            double humanYCoord = (*it)->getY();
            double zXCoord = z->getX();
            double zYCoord = z->getY();
            switch(z->getDirection())
            {
                case 0: //right
                    if (humanXCoord == zXCoord+SPRITE_WIDTH && humanYCoord == zYCoord)
                    {
                        actors.push_back(new Vomit(humanXCoord, humanYCoord, this));
                        return true;
                    }
                    break;
                case 180:   //left
                    if (humanXCoord == zXCoord-SPRITE_WIDTH && humanYCoord == zYCoord)
                    {
                        actors.push_back(new Vomit(humanXCoord, humanYCoord, this));
                        return true;
                    }
                    break;
                case 90:    //up
                    if (humanXCoord == zXCoord && humanYCoord == zYCoord+SPRITE_HEIGHT)
                    {
                        actors.push_back(new Vomit(humanXCoord, humanYCoord, this));
                        return true;
                    }
                    break;
                case 270: //down
                    if (humanXCoord == zXCoord && humanYCoord == zYCoord-SPRITE_HEIGHT)
                    {
                        actors.push_back(new Vomit(humanXCoord, humanYCoord, this));
                        return true;
                    }
                    break;
            }
            
            double dx = humanXCoord - zXCoord;
            double dy = humanYCoord - zYCoord;
            if ((dx*dx) + (dy*dy) <= 100)
            {
                int someRand = randInt(1, 3);
                if (someRand == 1)  // 1 in 3 chance of returning true
                {
                    switch(z->getDirection())
                    {
                        case 0: //right
                            actors.push_back(new Vomit(humanXCoord, humanYCoord, this));
                            return true;
                            break;
                            
                        case 180:   //left
                            actors.push_back(new Vomit(humanXCoord, humanYCoord, this));
                            return true;
                            break;
                            
                        case 90:    //up
                            actors.push_back(new Vomit(humanXCoord, humanYCoord, this));
                            return true;
                            break;
                            
                        case 270: //down
                            actors.push_back(new Vomit(humanXCoord, humanYCoord, this));
                            return true;
                            break;
                    }
                }
            }
        }
        else
            continue;
    }
    return false;   //no good vomit coordinates
}


void StudentWorld::createLandmine(double startX, double startY) {
    Landmine* newLandmine = new Landmine(startX, startY, this);
    actors.push_back(newLandmine);
}

void StudentWorld::createFlamethrower(double startX, double startY, Direction dir)
{
    switch(dir) {
        case BaseActor::right:
        {
            Flames* flame1 = new Flames(startX+SPRITE_WIDTH, startY, this);
            if (this->validFlamePosition(flame1))
            {
                actors.push_back(flame1);
                Flames* flame2 = new Flames(startX+(2*SPRITE_WIDTH), startY, this);
                if (this->validFlamePosition(flame2))
                {
                    actors.push_back(flame2);
                    Flames* flame3 = new Flames(startX+(3*SPRITE_WIDTH), startY, this);
                    if (this->validFlamePosition(flame3))
                        actors.push_back(flame3);
                    else
                        delete flame3;
                }
                else
                    delete flame2;
            }
            else
                delete flame1;
            break;
        }
        case BaseActor::left:
        {
            Flames* flame1 = new Flames(startX-SPRITE_WIDTH, startY, this);
            if (this->validFlamePosition(flame1))
            {
                actors.push_back(flame1);
                Flames* flame2 = new Flames(startX-(2*SPRITE_WIDTH), startY, this);
                if (this->validFlamePosition(flame2))
                {
                    actors.push_back(flame2);
                    Flames* flame3 = new Flames(startX-(3*SPRITE_WIDTH), startY, this);
                    if (this->validFlamePosition(flame3))
                        actors.push_back(flame3);
                    else
                        delete flame3;
                }
                else
                    delete flame2;
            }
            else
                delete flame1;
            break;
        }
        case BaseActor::up:
        {
            Flames* flame1 = new Flames(startX, startY+SPRITE_HEIGHT, this);
            if (this->validFlamePosition(flame1))
            {
                actors.push_back(flame1);
                Flames* flame2 = new Flames(startX, startY+(2*SPRITE_HEIGHT), this);
                if (this->validFlamePosition(flame2))
                {
                    actors.push_back(flame2);
                    Flames* flame3 = new Flames(startX, startY+(3*SPRITE_HEIGHT), this);
                    if (this->validFlamePosition(flame3))
                        actors.push_back(flame3);
                    else
                        delete flame3;
                }
                else
                    delete flame2;
            }
            else
                delete flame1;
            break;
        }
        case BaseActor::down:
        {
            Flames* flame1 = new Flames(startX, startY-SPRITE_HEIGHT, this);
            if (this->validFlamePosition(flame1))
            {
                actors.push_back(flame1);
                Flames* flame2 = new Flames(startX, startY-(2*SPRITE_HEIGHT), this);
                if (this->validFlamePosition(flame2))
                {
                    actors.push_back(flame2);
                    Flames* flame3 = new Flames(startX, startY-(3*SPRITE_HEIGHT), this);
                    if (this->validFlamePosition(flame3))
                        actors.push_back(flame3);
                    else
                        delete flame3;
                }
                else
                    delete flame2;
            }
            else
                delete flame1;
            break;
        }
    }
}

bool StudentWorld::createFlame(double startX, double startY) {
    Flames* newFlame = new Flames(startX, startY, this);
    if (this->validFlamePosition(newFlame))
    {
        actors.push_back(newFlame);
        return true;
    }
    else
    {
        delete newFlame;
        return false;
    }
}

void StudentWorld::createLandmineExplosion(double startX, double startY) {
    Flames* newFlame = new Flames(startX, startY, this);
    actors.push_back(newFlame);
    Pits* newPit = new Pits(startX, startY, this);
    actors.push_back(newPit);
    
    this->createFlame(startX, startY+SPRITE_HEIGHT); //top
    this->createFlame(startX-SPRITE_WIDTH, startY+SPRITE_HEIGHT); //top left
    this->createFlame(startX-SPRITE_WIDTH, startY);  //left
    this->createFlame(startX-SPRITE_WIDTH, startY-SPRITE_HEIGHT); //bot left
    this->createFlame(startX, startY-SPRITE_HEIGHT); //bot
    this->createFlame(startX+SPRITE_WIDTH, startY-SPRITE_HEIGHT); //bot right
    this->createFlame(startX+SPRITE_WIDTH, startY); //right
    this->createFlame(startX+SPRITE_WIDTH, startY+SPRITE_HEIGHT); //top right
    
}


bool StudentWorld::addVaccine(BaseActor* a)
{
    if (a == character)
    {
        this->modifyPoints(50);   //increase points by 50
        this->playSound(SOUND_GOT_GOODIE);
        character->addVaccine();
        return true;
    }
    return false;
}

bool StudentWorld::addLandmines(BaseActor *a)
{
    if (a == character)
    {
        this->modifyPoints(50);   //increase points by 50
        this->playSound(SOUND_GOT_GOODIE);
        character->addLandmines();
        return true;
    }
    return false;
}

bool StudentWorld::addFlames(BaseActor *a)
{
    if (a == character)
    {
        this->modifyPoints(50);   //increase points by 50
        this->playSound(SOUND_GOT_GOODIE);
        character->addFlames();
        return true;
    }
    return false;
}


void StudentWorld::playerExit(BaseActor* a)
{
    //if player steps on exit, check that number of humans is <= 0 before exit
    if (a->canBeInfected())
        
    if (a == character)
        if (numHumans <= 0)
            setLevelWin();
    
}

bool StudentWorld::findClosestHuman(BaseActor *a) {
    double aX, aY, bX, bY, dX, dY, smallest;
    smallest = 131072;   //set smallest to largest possible Euc. dist. 2*(256^2)
    aX = a->getX();
    aY = a->getY();
    BaseActor *closest = nullptr;
    list<BaseActor*>::iterator it;
    
    for (it = actors.begin(); it != actors.end(); it++)
    {
        if ((*it) == a)
            it++;
        
        if (! (*it)->isAlive())
            it++;
        
        if ( (*it)->canBeInfected() )
        {
            bX = (*it)->getX();
            bY = (*it)->getY();
            dX = aX - bY;
            dY = aX- bY;
            double dist = (dX*dX) + (dY*dY);
            if (dist < smallest)
            {
                closest = (*it);
                smallest = dist;
            }
        }
    }
    
    bX = closest->getX();
    bY = closest->getY();
    if (smallest > 6400) //80^2 = 6400
        return false; //getRandDirection
    else
    {
        if (aX == bX) //same row
        {
            if (bY > aY)    //target is up
                a->setDirection(BaseActor::up);
            else
                a->setDirection(BaseActor::down);
        }
        else if (aY == bY)
        {
            if (bX > aX)    //target is right
                a->setDirection(BaseActor::right);
            else
                a->setDirection(BaseActor::left);
        }
        else
        {
            switch(randInt(1, 2)) { //randomly send zombie either in vert or horiz
                case 1: //vertical
                    if (bY > aY)
                        a->setDirection(BaseActor::up);
                    else
                        a->setDirection(BaseActor::down);
                    break;
                    
                case 2: //horizontal
                    if (bX > aX)
                        a->setDirection(BaseActor::right);
                    else
                        a->setDirection(BaseActor::left);
            }
        }
    }
    return true;
    
}
