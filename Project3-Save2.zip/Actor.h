#ifndef ACTOR_H_
#define ACTOR_H_

#include "GraphObject.h"

class StudentWorld;
class GameWorld;
// Students:  Add code to this file, Actor.cpp, StudentWorld.h, and StudentWorld.cpp
/*
 GraphObject(int imageID, double startX, double startY,
 int startDirection = 0, int depth = 0);
 
 
 */


class BaseActor : public GraphObject
{
public:
    BaseActor(int imageID, double startX, double startY, Direction dir , int depth, StudentWorld* world);

    
    virtual void doSomething() = 0;     // must be pure virtual, a bunch of different actions
    //virtual bool beOverlapped() = 0;
    
    virtual void onCollision(BaseActor *a) = 0;
    void setDead();
    virtual void beKilled();    //everybody dies the same, some have sounds
    bool isAlive();                 //all actors will use this the same
    
    
    
    //identifiers
    virtual bool canBeKilled();
    virtual bool isMoveable();
    virtual bool notBlock();  //used for walls, can't be touched at all
    virtual bool flameCannotOverlap();  //used for walls and exits
    virtual bool canBeInfected();
    StudentWorld* getWorld();   //accessor for StudentWorld pointer
    
    void setInfected();
    bool isInfected();
    
private:
    bool m_alive;         //bool for whether actor is alive
    StudentWorld* m_world;
    bool m_isInfected;
    
    
};


//2nd layer of class structure

class MoveableActors : public BaseActor {
public:
    
    MoveableActors(int imageID, double startX, double startY, Direction dir, int depth, StudentWorld* world);
    
    int getTicks();
    void increaseTicks();
    void decreaseTicks();
    void setTicks(int n);
    void setTicksZero();
    
    virtual bool notBlock();
    virtual void onCollision(BaseActor *a);
    virtual bool isMoveable();
    virtual void doSomething() = 0; // still pure virtual, specific to most derived class
    
private:
    int m_ticks;
    
};

class Environment : public BaseActor {
public:
    Environment(int imageID, double startX, double startY, Direction dir, int depth, StudentWorld* world);
    
    virtual void doSomething();
    
private:
    
};


//3rd layer of class structure

//moveables

class Humans : public MoveableActors {
public:
    Humans(int imageID, double startX, double startY, Direction dir, int depth, StudentWorld* world);

    
       // this will be reset in Penelope and Citizens class
    virtual void doSomething();  //virtual because we will reassign so all humans have same funciton
    virtual bool canBeInfected();
    bool commonHumanActions();
    
    bool infectedProtocol();    //returns false if person dies, increments infected total otherwise
    int getInfectedTotal();
    void increaseInfectedTotal();
    void setHealthy();
    
private:
    int m_infectedTotal;
};

class Zombies : public MoveableActors {
    
public:
    const static int Z_MOVE = 1;
    Zombies(double startX, double startY, Direction dir, int depth, StudentWorld* world);

    virtual void beKilled();
    void modifyPlanDist(int n);
    void setPlanDistZero();
    int getPlanDist();
    bool commonZombieActions();
    void randomDirectionSelector();
    void mover();
    void randomPlanDist();
    
    
private:
    int m_planDist;
    
};


//environment

class Goodies : public Environment {
    
public:
    Goodies(int imageID, double startX, double startY, Direction dir, int depth, StudentWorld *world);
    
private:
    
};

class Permanents : public Environment {
    
public:
    
    Permanents(int imageID, double startX, double startY, Direction dir, int depth, StudentWorld *world);
    
    virtual bool canBeKilled(); //overwrite to false
    virtual void onCollision(BaseActor *a) = 0; //make this pure virt to keep this an ABC
//    virtual void doSomething();     //this will be set to return
    
private:
    
};



//4th layer of class structure

// penelope and citizens


class Penelope : public Humans {
    
public:
    Penelope(double startX, double startY, StudentWorld* world);
    
    const static int P_MOVE = 4;   // number of pixels per move
    
    virtual void doSomething();
    
    
    //identifier
    virtual void beKilled();
    
    //inventory functions
    void addVaccine();
    void addFlames();
    void addLandmines();
    
    //getters
    int getVaccines();
    int getFlames();
    int getLandmines();
    
private:
    int m_landmines;
    int m_vaccines;
    int m_flames;
    
    // actions
    void flamethrower();
    void placeLandmine();
    void useVaccine();

    
};

class Citizens : public Humans {
public:
    const static int C_MOVE = 2;
    
    Citizens(double startX, double startY, StudentWorld* world);
    virtual void beKilled();
    virtual void doSomething();
    
private:
    
};


// zombies

class DumbZombies : public Zombies {
    
public:
    DumbZombies(double startX, double startY, StudentWorld* world);
    virtual void doSomething();
    
private:
    
};

class SmartZombies : public Zombies {
    
public:
    SmartZombies(double startX, double startY, StudentWorld* world);
    virtual void doSomething();
    
private:
    
};


// goodies

class Vaccine : public Goodies {
    
public:
    Vaccine(double startX, double startY, StudentWorld* world);
    virtual void onCollision(BaseActor *a);
    
private:
    
};

class GasCan : public Goodies {
    
public:
    GasCan(double startX, double startY, StudentWorld* world);
    virtual void onCollision(BaseActor *a);
private:
    
};

class LandmineGoodie : public Goodies {
    
public:
    LandmineGoodie(double startX, double startY, StudentWorld* world);
    virtual void onCollision(BaseActor *a);
private:
    
};

class Landmine : public Goodies {
    
public:
    Landmine(double startX, double startY, StudentWorld* world);
    virtual void onCollision(BaseActor *a);
    virtual void doSomething();
private:
    int m_safetyTicks;
    
};


// permanents

class Projectiles : public Permanents {
    
public:
    Projectiles(int imageID, double startX, double startY, Direction dir, int depth, StudentWorld* world);
    virtual void doSomething();
    
private:
    int lifespan;
};

class Pits : public Permanents {
    
public:
    Pits(double startX, double startY, StudentWorld *world);
    virtual void onCollision(BaseActor *a);
    
private:
    
};

class Walls : public Permanents {
    
public:
    Walls(double startX, double startY, StudentWorld *world);
    virtual void onCollision(BaseActor *a);
    virtual bool notBlock();
    virtual bool flameCannotOverlap();
    
private:
    
};

class Exits : public Permanents {
    
public:
    Exits(double startX, double startY, StudentWorld *world);
    virtual void onCollision(BaseActor *a);
    virtual bool flameCannotOverlap();
    
private:
    
};


// 5th layer (only projectiles)

class Flames : public Projectiles {
    
public:
    Flames(double startX, double startY, StudentWorld* world);
    virtual void onCollision(BaseActor *a);
    
private:
    
};

class Vomit : public Projectiles {
    
public:
    Vomit(double startX, double startY, StudentWorld* world);
    virtual void onCollision(BaseActor *a);
    
private:
    
    
};


#endif // ACTOR_H_
