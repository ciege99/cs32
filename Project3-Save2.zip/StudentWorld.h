#ifndef STUDENTWORLD_H_
#define STUDENTWORLD_H_

#include "GameWorld.h"
#include "Actor.h"
#include <string>
#include <list>

class Penelope;
class BaseActor;

// Students:  Add code to this file, StudentWorld.cpp, Actor.h, and Actor.cpp

class StudentWorld : public GameWorld
{
public:
    StudentWorld(std::string assetPath);
    ~StudentWorld();
    virtual int init();
    virtual int move();
    virtual void cleanUp();
    
    
    //getters
    int getHumans();    //return num of citizens
    
    bool overlap(double newX, double newY, BaseActor* a);
    bool vomitDistance(BaseActor* z);
    bool blockMovement(double newX, double newY, BaseActor* a);
    bool validFlamePosition(BaseActor* a);
    bool findClosestHuman(BaseActor* a);
    
    void setLevelWin();      // set game to be won
    void modifyPoints(int num);
    void setStats();

    
    
    //exit
    void playerExit(BaseActor* a);
    
    
    //creators
    void createLandmine(double startX, double startY);
    void createLandmineExplosion(double startX, double startY);
    void createFlamethrower(double startX, double startY, Direction dir);
    bool createFlame(double startX, double startY);
    
    
    //adders
    bool addVaccine(BaseActor *a);
    bool addLandmines(BaseActor *a);
    bool addFlames(BaseActor *a);

private:
    Penelope *character;
    std::list<BaseActor *> actors;
    int numHumans;
    bool levelWon;
    int numPoints;

};

#endif // STUDENTWORLD_H_
